#!/usr/bin/env python
# coding: utf-8

# In[739]:


import pandas as pd
import os
import matplotlib
import numpy as np
import matplotlib.pyplot as plt
import datetime as dt
from bokeh.plotting import figure, show, output_file
from bokeh.models import CategoricalColorMapper, ColumnDataSource
import seaborn as sns
from math import pi
from bokeh.models import HoverTool
from bokeh.models import ColumnDataSource, CustomJS
from bokeh.layouts import layout, widgetbox
from bokeh.models import ColumnDataSource, Label


# In[740]:


data = pd.read_csv(r'Li Wenliang - 2 media.csv', sep=',',parse_dates=['dt'])


# In[741]:


data.dropna(inplace= True)


# In[742]:


data.rename(columns={'dt':'date'}, inplace=True)


# In[743]:


pal = sns.color_palette("hls", 2)
colors = pal.as_hex()


# In[744]:


colormap = CategoricalColorMapper(palette=colors, factors =data.media.unique())


# In[745]:


source = ColumnDataSource(data=dict( 
	day= data.date.dt.day,
	value = data.value,
	media  =data.media,
    date = data.date
	))


# In[746]:


p = figure(title = "Timelines of Posts Containing the Keyword 'Li Wenliang'",x_axis_type="datetime",
	plot_width=900, plot_height=400,
	tools="hover, save, pan, box_zoom, reset, wheel_zoom",
	tooltips = [('day', '@day'), ('count', '@value'), ('media', '@media')])


# In[747]:


p.xaxis.axis_label = 'Date'
p.yaxis.axis_label = 'Counts'


# In[748]:


p.xaxis.major_label_orientation = pi/10

p.circle(x = 'date', y = 'value', source = source, 
         color={'field': 'media', 'transform': colormap},
         fill_alpha=0.2, size=10)


# In[749]:


citation1 = Label(x=650,y=305, x_units='screen', y_units='screen',
                 text=' blue circle - state media ', render_mode='css',text_color = 'navy',
                 border_line_color='teal', border_line_alpha=2.0,
                 background_fill_color='white', background_fill_alpha=1.0)


# In[750]:


citation2 = Label(x=630,y=275, x_units='screen', y_units='screen',
                 text=' red circle - business media ', render_mode='css',text_color = 'firebrick',
                 border_line_color='firebrick', border_line_alpha=2.0,
                 background_fill_color='white', background_fill_alpha=1.0)


# In[751]:


p.add_layout(citation1)
p.add_layout(citation2)


# In[752]:


output_file("Li Wenliang - two media.html", title="Timelines of Posts Containing the Keyword 'Li Wenliang")


# In[753]:


show(p)

