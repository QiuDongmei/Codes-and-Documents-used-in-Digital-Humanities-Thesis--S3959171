#!/usr/bin/env python
# coding: utf-8

# In[18]:


import pandas as pd
from snownlp import SnowNLP
from snownlp import sentiment
import matplotlib.pyplot as plt
import re
import jieba.posseg as pseg
import csv
import codecs
import statistics
import glob


# In[19]:


stopwords = [line.rstrip() for line in open('stopwords.txt', 'r', encoding='utf-8')]


def proc_text(raw_line):
    filter_pattern = re.compile('[^\u4E00-\u9FD5]+')
    chinese_only = filter_pattern.sub('', raw_line)
    words_lst = pseg.cut(chinese_only)
    meaninful_words = []
    for word, flag in words_lst:
        if word not in stopwords:
            meaninful_words.append(word)
    return ''.join(meaninful_words)


# In[20]:


csv_file = []
list = []
path = "*.csv"
for fname in glob.glob(path):
    csv_file.append(fname)


# In[21]:


for csv in csv_file:
    df=pd.read_csv(csv,header=None,usecols=[2])


# In[22]:


comment_list=[]
for csv in csv_file:
   comment_list.append(pd.read_csv(csv,header=None,usecols=[2]).values.tolist()) 


# In[23]:


cln_comment_lists=[]
for comments in comment_list:
    cln_comment_list=[]
    for comment in comments:  
        cln_comment_list.append(proc_text(str(comment)))
    cln_comment_lists.append(cln_comment_list) 


# In[24]:


Score = []
for CLN_COMMENTS in cln_comment_lists: 
    score=[]
    for CLN_COMMENT in CLN_COMMENTS:
        try:
            s = SnowNLP(CLN_COMMENT)
            score.append(s.sentiments)
        except: 
            print('Something is wrong.')
            score.append(0.5)
    Score.append(statistics.mean(score))

result = []
i = 0
while i<len(Score):
    result.append(Score[i]-0.5)
    i = i + 1


# In[25]:


result_02_07 = result[0:29]
result_02_08 = result[29:31]
result_03_19 = result[31:43]
result_04_02 = result[43:49]
result_05_10 = result[49:50]
results_mean = []
results_mean.append(statistics.mean(result_02_07))
results_mean.append(statistics.mean(result_02_08))
results_mean.append(statistics.mean(result_03_19))
results_mean.append(statistics.mean(result_04_02))
results_mean.append(statistics.mean(result_05_10))


# In[26]:


import datetime

x = datetime.datetime(2020, 2, 7)
x1 = datetime.datetime(2020, 2, 8)
x2= datetime.datetime(2020, 3, 19)
x3= datetime.datetime(2020, 4, 2)
x4= datetime.datetime(2020, 5, 10)


list_time = []
list_time.append(x.strftime('%b/%d/%Y'))
list_time.append(x1.strftime('%b/%d/%Y'))
list_time.append(x2.strftime('%b/%d/%Y'))
list_time.append(x3.strftime('%b/%d/%Y'))
list_time.append(x4.strftime('%b/%d/%Y'))


# In[27]:


d = {"Posts Containing Keywords of 'Li Wenliang' from Four State Media":list_time,'Sentiment Score':results_mean}
df = pd.DataFrame(d)

df.plot("Posts Containing Keywords of 'Li Wenliang' from Four State Media", 'Sentiment Score', kind='bar', rot=90)


# In[28]:


import numpy as np

plt.plot(np.arange(0, 50, 1), result, 'k-')
plt.xlabel('Number')
plt.ylabel('Sentiment')
plt.title("Sentiment Fluctuation of Posts Contaning Keywords of 'Li Wenliang'")
plt.show()

