#!/usr/bin/env python
# coding: utf-8

# In[7]:


import pandas as pd
from snownlp import SnowNLP
from snownlp import sentiment
import matplotlib.pyplot as plt
import re
import jieba.posseg as pseg
import csv
import codecs
import glob
import jieba


# In[8]:


stopwords = [line.rstrip() for line in open('stopwords.txt', 'r', encoding='utf-8')]


def proc_text(raw_line):
    filter_pattern = re.compile('[^\u4E00-\u9FD5]+')
    chinese_only = filter_pattern.sub('', raw_line)
    words_lst = pseg.cut(chinese_only)
    meaninful_words = []
    for word, flag in words_lst:
        if word not in stopwords:
            meaninful_words.append(word)
    return ''.join(meaninful_words)


# In[9]:


csv_file = []
list = []
path = "*.csv"
for fname in glob.glob(path):
    csv_file.append(fname)


# In[10]:


for csv in csv_file:
    df=pd.read_csv(csv,header=None,usecols=[2])


# In[11]:


comment_list=[]
for csv in csv_file:
   comment_list.append(pd.read_csv(csv,header=None,usecols=[2]).values.tolist()) 


# In[12]:


cln_comment_lists=[]
for comments in comment_list:
    cln_comment_list=[]
    for comment in comments:  
            cln_comment_list.append(proc_text(str(comment)))
    cln_comment_lists.append(cln_comment_list) 


# In[13]:


corpus = cln_comment_lists


# In[14]:


Corpus = []
for c in corpus[0]:
    if c!= '':
        Corpus.append(c)
        
word_list = []
for i in range(len(Corpus)):
    a = SnowNLP(Corpus[i])
    s = a.words
    word_list.append(s)

all_sents= []
for sublist in word_list:
    for item in sublist:
        all_sents.append(item)

import math
from collections import Counter

for i in range(len(all_sents)):
    countlist = []
    count = Counter(all_sents)
    countlist.append(count)
print('李-50-->', countlist)

