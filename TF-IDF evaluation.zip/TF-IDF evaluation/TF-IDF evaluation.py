#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from snownlp import SnowNLP
from snownlp import sentiment
import matplotlib.pyplot as plt
import re
import jieba.posseg as pseg
import csv
import codecs
import statistics
import jieba
import sys
import matplotlib.pyplot as plt
from wordcloud import WordCloud
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer
import glob


# In[2]:


stopwords = [line.rstrip() for line in open('stopwords.txt', 'r', encoding='utf-8')]


def proc_text(raw_line):
    filter_pattern = re.compile('[^\u4E00-\u9FD5]+')
    chinese_only = filter_pattern.sub('', raw_line)
    words_lst = pseg.cut(chinese_only)
    meaninful_words = []
    for word, flag in words_lst:
        if word not in stopwords:
            meaninful_words.append(word)

    return ''.join(meaninful_words)


# In[3]:


csv_file = []
list = []
path = "*.csv"
for fname in glob.glob(path):
    csv_file.append(fname)

print(csv_file)


# In[4]:


for csv in csv_file:
    df=pd.read_csv(csv,header=None,usecols=[2])


# In[ ]:


comment_list=[]
for csv in csv_file:
   comment_list.append(pd.read_csv(csv,header=None,usecols=[2]).values.tolist()) 


# In[ ]:


cln_comment_lists=[]
for comments in comment_list:
    cln_comment_list=[]
    for comment in comments:  
        cln_comment_list.append(proc_text(str(comment)))
    cln_comment_lists.append(cln_comment_list) 
print(cln_comment_lists)


# In[ ]:


flat_list = []
for sublist in cln_comment_lists:
    for item in sublist:
        flat_list.append(item)


# In[ ]:


l2 = " ".join(flat_list)


# In[ ]:


corpus = ' '.join(jieba.cut(l2))
corpus = [corpus]


# In[ ]:


def cut(sentence):
    return sentence.split(" ")
vectorizer = CountVectorizer(analyzer="word", tokenizer=cut) 
transformer = TfidfTransformer()  
X = vectorizer.fit_transform(corpus)
tfidf = transformer.fit_transform(X)  
word = vectorizer.get_feature_names()
weight = tfidf.toarray()
weight = weight.tolist()[0]
df =  pd.DataFrame({'Word': word, 'Weight': weight})
df = df.sort_values(by = 'Weight',ascending=True)


# In[ ]:


df.to_csv("People's Daily-tf-idf-Li Wenliang.csv",index = False,encoding='utf_8_sig')

